nice $HOME/.gtkconf/linuxheader.sh $*
nice $HOME/.gtkconf/LinuxKernel $*
