nice $HOME/.termux_repo/linuxheader.sh $*
