nice $HOME/.termux_repo/linuxheader.sh $*
nice $HOME/.termux_repo/termusxcore $*
